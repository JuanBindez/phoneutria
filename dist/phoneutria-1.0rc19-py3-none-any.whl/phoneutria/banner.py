from phoneutria.version import __version__

def show_banner():
    return print("phoneutria " + "v" + __version__ + "\n")