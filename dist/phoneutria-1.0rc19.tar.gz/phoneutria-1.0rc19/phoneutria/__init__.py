__title__ = "phoneutria"
__author__ = "Juan Bindez"
__license__ = "GPLv2 License"
__js__ = None
__js_url__ = None

import os

from phoneutria.version import __version__
from phoneutria.__main__ import Chelicera